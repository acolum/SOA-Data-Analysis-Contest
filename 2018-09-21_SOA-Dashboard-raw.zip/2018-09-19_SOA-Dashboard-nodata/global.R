library(shiny)
library(shinydashboard)
library(DT)
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)
library(plotly)

# Obtain .txt data from http://cdn-origin.soa.org/research/2009-15_Data_20180601.zip
# salesdata <- read_delim("2009-15 Data 20180601.txt", 
#                         "\t", escape_double = FALSE, trim_ws = TRUE)
# OR
# Obtain .RDS data from https://s3-us-west-1.amazonaws.com/soa-data-analysis-contest/SOAdata.rds
# salesdata <- readRDS("SOAdata.rds")

salesdata <- salesdata %>% 
  mutate_if(is.character, factor)