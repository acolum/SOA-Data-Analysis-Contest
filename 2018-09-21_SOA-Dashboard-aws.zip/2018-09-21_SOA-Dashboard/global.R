library(shiny)
library(shinydashboard)
library(DT)
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)
library(plotly)

salesdata <- readRDS(gzcon(url("https://s3-us-west-1.amazonaws.com/soa-data-analysis-contest/SOAdata.rds")))
salesdata <- salesdata %>% 
  mutate_if(is.character, factor)