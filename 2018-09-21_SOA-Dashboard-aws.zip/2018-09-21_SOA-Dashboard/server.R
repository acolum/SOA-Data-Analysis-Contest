shinyServer(function(input, output, session) {
  ### Reactive Dataset: Summary
  salesdata_reactive <- reactive({
    salesdata %>%
      filter(`Issue Year` >= input$summary_issueyear[1] &
               `Issue Year` <= input$summary_issueyear[2]) %>%
      filter(`Observation Year` >= input$summary_obsyear[1] &
               `Observation Year` <= input$summary_obsyear[2]) %>% 
      filter(`Issue Age` >= input$summary_issueage[1] &
               `Issue Age` <= input$summary_issueage[2]) %>% 
      filter(`Attained Age` >= input$summary_attainedage[1] &
               `Attained Age` <= input$summary_attainedage[2]) %>% 
      filter(Duration >= input$summary_duration[1] &
               Duration <= input$summary_duration[2]) %>% 
      subset(Gender %in% input$summary_gender) %>% # CORRECT
      subset(`Smoker Status` %in% input$summary_smoker) %>%
      subset(Select_Ultimate_Indicator %in% input$summary_selectult) %>% 
      subset(`Insurance Plan` %in% input$summary_insuranceplan) %>% 
      subset(`Face Amount Band` %in% input$summary_faceamtband) %>% 
      subset(`SOA Anticipated Level Term Period` %in% input$summary_soaanticipated) %>% 
      subset(`SOA Guaranteed Level Term Period` %in% input$summary_soaguaranteed) %>% 
      subset(`SOA Post level term indicator` %in% input$summary_soapostlevel) %>% 
      # filter(`Age Basis` >= input$summary_agebasis[1] &
      #          `Age Basis` <= input$summary_agebasis[2]) %>% 
      # filter(`Number of Preferred Classes` >= input$summary_numprefer[1] &
      #          `Number of Preferred Classes` <= input$summary_numprefer[2]) %>% 
      # filter(`Preferred Class` >= input$summary_prefer[1] &
      #          `Preferred Class` <= input$summary_prefer[2]) %>% 
      filter(`Number of Deaths` >= input$summary_deaths[1] &
               `Number of Deaths` <= input$summary_deaths[2]) %>% 
      filter(`Death Claim Amount` >= input$summary_deathclaim[1] &
               `Death Claim Amount` <= input$summary_deathclaim[2]) %>% 
      filter(`Policies Exposed` >= input$summary_policies[1] &
               `Policies Exposed` <= input$summary_policies[2]) %>% 
      filter(`Amount Exposed` >= input$summary_amount[1] &
               `Amount Exposed` <= input$summary_amount[2]) %>% 
      filter(`Expected Death QX7580E by Amount` >= input$summary_eda1[1] &
               `Expected Death QX7580E by Amount` <= input$summary_eda1[2]) %>% 
      filter(`Expected Death QX2001VBT by Amount` >= input$summary_eda2[1] &
               `Expected Death QX2001VBT by Amount` <= input$summary_eda2[2]) %>% 
      filter(`Expected Death QX2008VBT by Amount` >= input$summary_eda3[1] &
               `Expected Death QX2008VBT by Amount` <= input$summary_eda3[2]) %>% 
      filter(`Expected Death QX2008VBTLU by Amount` >= input$summary_eda4[1] &
               `Expected Death QX2008VBTLU by Amount` <= input$summary_eda4[2]) %>% 
      filter(`Expected Death QX2015VBT by Amount` >= input$summary_eda5[1] &
               `Expected Death QX2015VBT by Amount` <= input$summary_eda5[2]) %>% 
      filter(`Expected Death QX7580E by Policy` >= input$summary_edp1[1] &
               `Expected Death QX7580E by Policy` <= input$summary_edp1[2]) %>% 
      filter(`Expected Death QX2001VBT by Policy` >= input$summary_edp2[1] &
               `Expected Death QX2001VBT by Policy` <= input$summary_edp2[2]) %>% 
      filter(`Expected Death QX2008VBT by Policy` >= input$summary_edp3[1] &
               `Expected Death QX2008VBT by Policy` <= input$summary_edp3[2]) %>% 
      filter(`Expected Death QX2008VBTLU by Policy` >= input$summary_edp4[1] &
               `Expected Death QX2008VBTLU by Policy` <= input$summary_edp4[2]) %>% 
      filter(`Expected Death QX2015VBT by Policy` >= input$summary_edp5[1] &
               `Expected Death QX2015VBT by Policy` <= input$summary_edp5[2])
  })
  
  df_duration <- reactive({
    salesdata_reactive() %>% 
      group_by(Duration) %>% 
      summarise(Policies = sum(`Policies Exposed`),
                Exposure = sum(`Amount Exposed`),
                Deaths_Num = sum(`Number of Deaths`),
                Deaths_Amt = sum(`Death Claim Amount`),
                EDeaths_Num_QX2001VBT = sum(`Expected Death QX2001VBT by Policy`),
                EDeaths_Amt_QX2001VBT = sum(`Expected Death QX2001VBT by Amount`),
                EDeaths_Num_QX2008VBT = sum(`Expected Death QX2008VBT by Policy`),
                EDeaths_Amt_QX2008VBT = sum(`Expected Death QX2008VBT by Amount`),
                EDeaths_Num_QX2008VBTLU = sum(`Expected Death QX2008VBTLU by Policy`),
                EDeaths_Amt_QX2008VBTLU = sum(`Expected Death QX2008VBTLU by Amount`),
                EDeaths_Num_QX2015VBT = sum(`Expected Death QX2015VBT by Policy`),
                EDeaths_Amt_QX2015VBT = sum(`Expected Death QX2015VBT by Amount`),
                EDeaths_Num_QX7580E = sum(`Expected Death QX7580E by Policy`),
                EDeaths_Amt_QX7580E = sum(`Expected Death QX7580E by Amount`)) %>% 
      mutate(Deaths_Num_Cap = replace(Deaths_Num, Deaths_Num > 3007, 3007)) %>%
      mutate(AE_Num_QX2001VBT = Deaths_Num/EDeaths_Num_QX2001VBT,
             AE_Amt_QX2001VBT = Deaths_Amt/EDeaths_Amt_QX2001VBT,
             AE_Num_QX2008VBT = Deaths_Num/EDeaths_Num_QX2008VBT,
             AE_Amt_QX2008VBT = Deaths_Amt/EDeaths_Amt_QX2008VBT,
             AE_Num_QX2008VBTLU = Deaths_Num/EDeaths_Num_QX2008VBTLU,
             AE_Amt_QX2008VBTLU = Deaths_Amt/EDeaths_Amt_QX2008VBTLU,
             AE_Num_QX2015VBT = Deaths_Num/EDeaths_Num_QX2015VBT,
             AE_Amt_QX2015VBT = Deaths_Amt/EDeaths_Amt_QX2015VBT,
             AE_Num_QX7580E = Deaths_Num/EDeaths_Num_QX7580E,
             AE_Amt_QX7580E = Deaths_Amt/EDeaths_Amt_QX7580E) %>% 
      mutate(Cred_AE_Num_QX2001VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2001VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2001VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2001VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX2008VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2008VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2008VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2008VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX2008VBTLU = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2008VBTLU) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2008VBTLU = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2008VBTLU) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX2015VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2015VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2015VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2015VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX7580E = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX7580E) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX7580E = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX7580E) + (1-sqrt(Deaths_Num_Cap/3007)))
  })
  
  
  df_age <- reactive({
    salesdata_reactive() %>% 
      group_by(`Attained Age`) %>% 
      summarise(Policies = sum(`Policies Exposed`),
                Exposure = sum(`Amount Exposed`),
                Deaths_Num = sum(`Number of Deaths`),
                Deaths_Amt = sum(`Death Claim Amount`),
                EDeaths_Num_QX2001VBT = sum(`Expected Death QX2001VBT by Policy`),
                EDeaths_Amt_QX2001VBT = sum(`Expected Death QX2001VBT by Amount`),
                EDeaths_Num_QX2008VBT = sum(`Expected Death QX2008VBT by Policy`),
                EDeaths_Amt_QX2008VBT = sum(`Expected Death QX2008VBT by Amount`),
                EDeaths_Num_QX2008VBTLU = sum(`Expected Death QX2008VBTLU by Policy`),
                EDeaths_Amt_QX2008VBTLU = sum(`Expected Death QX2008VBTLU by Amount`),
                EDeaths_Num_QX2015VBT = sum(`Expected Death QX2015VBT by Policy`),
                EDeaths_Amt_QX2015VBT = sum(`Expected Death QX2015VBT by Amount`),
                EDeaths_Num_QX7580E = sum(`Expected Death QX7580E by Policy`),
                EDeaths_Amt_QX7580E = sum(`Expected Death QX7580E by Amount`)) %>%
      mutate(Deaths_Num_Cap = replace(Deaths_Num, Deaths_Num > 3007, 3007)) %>%
      mutate(AE_Num_QX2001VBT = Deaths_Num/EDeaths_Num_QX2001VBT,
             AE_Amt_QX2001VBT = Deaths_Amt/EDeaths_Amt_QX2001VBT,
             AE_Num_QX2008VBT = Deaths_Num/EDeaths_Num_QX2008VBT,
             AE_Amt_QX2008VBT = Deaths_Amt/EDeaths_Amt_QX2008VBT,
             AE_Num_QX2008VBTLU = Deaths_Num/EDeaths_Num_QX2008VBTLU,
             AE_Amt_QX2008VBTLU = Deaths_Amt/EDeaths_Amt_QX2008VBTLU,
             AE_Num_QX2015VBT = Deaths_Num/EDeaths_Num_QX2015VBT,
             AE_Amt_QX2015VBT = Deaths_Amt/EDeaths_Amt_QX2015VBT,
             AE_Num_QX7580E = Deaths_Num/EDeaths_Num_QX7580E,
             AE_Amt_QX7580E = Deaths_Amt/EDeaths_Amt_QX7580E) %>% 
      mutate(Cred_AE_Num_QX2001VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2001VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2001VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2001VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX2008VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2008VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2008VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2008VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX2008VBTLU = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2008VBTLU) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2008VBTLU = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2008VBTLU) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX2015VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX2015VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX2015VBT = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX2015VBT) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Num_QX7580E = (sqrt(Deaths_Num_Cap/3007)*AE_Num_QX7580E) + (1-sqrt(Deaths_Num_Cap/3007)),
             Cred_AE_Amt_QX7580E = (sqrt(Deaths_Num_Cap/3007)*AE_Amt_QX7580E) + (1-sqrt(Deaths_Num_Cap/3007))) 
  })
  
  ############################################################ Age 1 ########################################
  plotType_age1 <- function(x, type) {
    switch(type,
           "Exposed Policies" = ggplot(x, aes(x = `Attained Age`, y = Policies/1000000)) +
             geom_bar(stat = "identity") +
             xlab("Attained Age") +
             ylab("Exposed Policies (Millions)") +
             labs(title = "Exposed Policies vs. Attained Age of Policy Holders") +
             theme(legend.position = "none"),
           "Exposed Amounts" = ggplot(x, aes(x = `Attained Age`, y = Exposure/1000000000)) +
             geom_bar(stat = "identity") +
             xlab("Attained Age") +
             ylab("Exposed Amounts (Billions)") +
             labs(title = "Exposed Amounts vs. Attained Age of Policy Holders") +
             theme(legend.position = "none")
    )
  }
  
  output$age1_plot <- renderPlotly({
    ggplot_age1 <- plotType_age1(df_age(), input$pType_age1)
    ggplotly(ggplot_age1)
  })
  
  ############################################################ Duration 1 ########################################
  plotType_duration1 <- function(x, type) {
    switch(type,
           "Exposed Policies" = ggplot(x, aes(x = Duration, y = Policies/1000000)) +
             geom_bar(stat = "identity") +
             xlab("Duration") +
             ylab("Exposed Policies (Millions)") +
             labs(title = "Exposed Policies vs. Duration of Policies") +
             theme(legend.position = "none"),
           "Exposed Amounts" = ggplot(x, aes(x = Duration, y = Exposure/1000000000)) +
             geom_bar(stat = "identity") +
             xlab("Duration") +
             ylab("Exposed Amounts (Billions)") +
             labs(title = "Exposed Amounts vs. Duration of Policies") +
             theme(legend.position = "none")
    )
  }
  
  output$duration1_plot <- renderPlotly({
    ggplot_duration1 <- plotType_duration1(df_duration(), input$pType_duration1)
    ggplotly(ggplot_duration1)
  })
  
  ############################################################ Age 2 ########################################
  plotType_age2 <- function(x, type) {
    switch(type,
           "A/E Policies" = ggplot(x, aes(x = `Attained Age`)) +
             geom_line(aes(y = AE_Num_QX2001VBT, color = "AE_Num_QX2001VBT")) +
             geom_line(aes(y = AE_Num_QX2008VBT, color = "AE_Num_QX2008VBT")) +
             geom_line(aes(y = AE_Num_QX2008VBTLU, color = "AE_Num_QX2008VBTLU")) +
             geom_line(aes(y = AE_Num_QX2015VBT, color = "AE_Num_QX2015VBT")) +
             geom_line(aes(y = AE_Num_QX7580E, color = "AE_Num_QX7580E")) +
             geom_line(aes(y = Cred_AE_Num_QX2001VBT, color = "Cred_AE_Num_QX2001VBT")) +
             geom_line(aes(y = Cred_AE_Num_QX2008VBT, color = "Cred_AE_Num_QX2008VBT")) +
             geom_line(aes(y = Cred_AE_Num_QX2008VBTLU, color = "Cred_AE_Num_QX2008VBTLU")) +
             geom_line(aes(y = Cred_AE_Num_QX2015VBT, color = "Cred_AE_Num_QX2015VBT")) +
             geom_line(aes(y = Cred_AE_Num_QX7580E, color = "Cred_AE_Num_QX7580E")) +
             geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
             scale_color_manual(values = c("#20E500",
                                           "#22CE13",
                                           "#24B726",
                                           "#27A039",
                                           "#29894C",
                                           "#E54300",
                                           "#D33C13",
                                           "#C23526",
                                           "#B12E39",
                                           "#9F284C")) +
             xlab("Attained Age") +
             ylab("Actual/Expected Deaths") +
             labs(title = "A/E Deaths vs. Attained Age of Policy Holders") +
             theme(legend.position = "none"),
           "A/E Exposures" = ggplot(x, aes(x = `Attained Age`)) +
             geom_line(aes(y = AE_Amt_QX2001VBT, color = "AE_Amt_QX2001VBT")) +
             geom_line(aes(y = AE_Amt_QX2008VBT, color = "AE_Amt_QX2008VBT")) +
             geom_line(aes(y = AE_Amt_QX2008VBTLU, color = "AE_Amt_QX2008VBTLU")) +
             geom_line(aes(y = AE_Amt_QX2015VBT, color = "AE_Amt_QX2015VBT")) +
             geom_line(aes(y = AE_Amt_QX7580E, color = "AE_Amt_QX7580E")) +
             geom_line(aes(y = Cred_AE_Amt_QX2001VBT, color = "Cred_AE_Amt_QX2001VBT")) +
             geom_line(aes(y = Cred_AE_Amt_QX2008VBT, color = "Cred_AE_Amt_QX2008VBT")) +
             geom_line(aes(y = Cred_AE_Amt_QX2008VBTLU, color = "Cred_AE_Amt_QX2008VBTLU")) +
             geom_line(aes(y = Cred_AE_Amt_QX2015VBT, color = "Cred_AE_Amt_QX2015VBT")) +
             geom_line(aes(y = Cred_AE_Amt_QX7580E, color = "Cred_AE_Amt_QX7580E")) +
             geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
             scale_color_manual(values = c("#20E500",
                                           "#22CE13",
                                           "#24B726",
                                           "#27A039",
                                           "#29894C",
                                           "#E54300",
                                           "#D33C13",
                                           "#C23526",
                                           "#B12E39",
                                           "#9F284C")) +
             xlab("Attained Age") +
             ylab("Actual/Expected Death Amounts") +
             labs(title = "A/E Death Amounts vs. Attained Age of Policy Holders") +
             theme(legend.position = "none")
    )
  }
  
  output$age2_plot <- renderPlotly({
    ggplot_age2 <- plotType_age2(df_age(), input$pType_age2)
    ggplotly(ggplot_age2)
  })
  
  ############################################################ Duration 2 ########################################
  plotType_duration2 <- function(x, type) {
    switch(type,
           "A/E Policies" = ggplot(x, aes(x = Duration)) +
             geom_line(aes(y = AE_Num_QX2001VBT, color = "AE_Num_QX2001VBT")) +
             geom_line(aes(y = AE_Num_QX2008VBT, color = "AE_Num_QX2008VBT")) +
             geom_line(aes(y = AE_Num_QX2008VBTLU, color = "AE_Num_QX2008VBTLU")) +
             geom_line(aes(y = AE_Num_QX2015VBT, color = "AE_Num_QX2015VBT")) +
             geom_line(aes(y = AE_Num_QX7580E, color = "AE_Num_QX7580E")) +
             geom_line(aes(y = Cred_AE_Num_QX2001VBT, color = "Cred_AE_Num_QX2001VBT")) +
             geom_line(aes(y = Cred_AE_Num_QX2008VBT, color = "Cred_AE_Num_QX2008VBT")) +
             geom_line(aes(y = Cred_AE_Num_QX2008VBTLU, color = "Cred_AE_Num_QX2008VBTLU")) +
             geom_line(aes(y = Cred_AE_Num_QX2015VBT, color = "Cred_AE_Num_QX2015VBT")) +
             geom_line(aes(y = Cred_AE_Num_QX7580E, color = "Cred_AE_Num_QX7580E")) +
             geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
             scale_color_manual(values = c("#20E500",
                                           "#22CE13",
                                           "#24B726",
                                           "#27A039",
                                           "#29894C",
                                           "#E54300",
                                           "#D33C13",
                                           "#C23526",
                                           "#B12E39",
                                           "#9F284C")) +
             xlab("Duration") +
             ylab("Actual/Expected Deaths") +
             labs(title = "A/E Deaths vs. Duration of Policies") +
             theme(legend.position = "none"),
           "A/E Exposures" = ggplot(x, aes(x = Duration)) +
             geom_line(aes(y = AE_Amt_QX2001VBT, color = "AE_Amt_QX2001VBT")) +
             geom_line(aes(y = AE_Amt_QX2008VBT, color = "AE_Amt_QX2008VBT")) +
             geom_line(aes(y = AE_Amt_QX2008VBTLU, color = "AE_Amt_QX2008VBTLU")) +
             geom_line(aes(y = AE_Amt_QX2015VBT, color = "AE_Amt_QX2015VBT")) +
             geom_line(aes(y = AE_Amt_QX7580E, color = "AE_Amt_QX7580E")) +
             geom_line(aes(y = Cred_AE_Amt_QX2001VBT, color = "Cred_AE_Amt_QX2001VBT")) +
             geom_line(aes(y = Cred_AE_Amt_QX2008VBT, color = "Cred_AE_Amt_QX2008VBT")) +
             geom_line(aes(y = Cred_AE_Amt_QX2008VBTLU, color = "Cred_AE_Amt_QX2008VBTLU")) +
             geom_line(aes(y = Cred_AE_Amt_QX2015VBT, color = "Cred_AE_Amt_QX2015VBT")) +
             geom_line(aes(y = Cred_AE_Amt_QX7580E, color = "Cred_AE_Amt_QX7580E")) +
             geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
             scale_color_manual(values = c("#20E500",
                                           "#22CE13",
                                           "#24B726",
                                           "#27A039",
                                           "#29894C",
                                           "#E54300",
                                           "#D33C13",
                                           "#C23526",
                                           "#B12E39",
                                           "#9F284C")) +
             xlab("Duration") +
             ylab("Actual/Expected Death Amounts") +
             labs(title = "A/E Death Amounts vs. Duration of Policies") +
             theme(legend.position = "none")
    )
  }
  
  output$duration2_plot <- renderPlotly({
    ggplot_duration2 <- plotType_duration2(df_duration(), input$pType_duration2)
    ggplotly(ggplot_duration2)
  })
  #########################################################################################
  ## App Metrics: output session info
  output$sessionInfo <- renderPrint({
    capture.output(sessionInfo())
  })
  # Stop app when browser closes
  session$onSessionEnded(stopApp)
})